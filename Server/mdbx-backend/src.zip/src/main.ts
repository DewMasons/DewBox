import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { HttpExceptionFilter } from './filters/http-exception.filter';
import { Logger, ValidationPipe } from '@nestjs/common';  // Add ValidationPipe to imports

async function bootstrap() {
  const logger = new Logger('Bootstrap');
  const app = await NestFactory.create(AppModule, {
    logger: ['error', 'warn', 'debug', 'log', 'verbose'],
  });

  app.useGlobalFilters(new HttpExceptionFilter());

  // Add global prefix for all routes
  app.setGlobalPrefix('api');
  
  // Enable detailed error logging
  app.useGlobalFilters(new HttpExceptionFilter());

  // Request logging middleware with error handling
  app.use((req, res, next) => {
    logger.log(`${req.method} ${req.url}`);
    next();
  });

  // Enable CORS with credentials
  app.enableCors({
    origin: ['http://localhost:5173', 'http://localhost:5174'],
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
    credentials: true,
    allowedHeaders: ['Content-Type', 'Accept', 'Authorization'],
  });
  
  // Validation with better error messages
  app.useGlobalPipes(new ValidationPipe({
    transform: true,
    whitelist: true,
    forbidNonWhitelisted: true,
    enableDebugMessages: true,
    disableErrorMessages: false,
  }));

  // Change the listen port
  await app.listen(3000);
  logger.log(`Application is running on: http://localhost:3000`);
}
bootstrap();
