import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Subscriber } from '../entities/subscriber.entity';
@Injectable()
export class SubscriberService {
  constructor(
    @InjectRepository(Subscriber)
    private subscriberRepository: Repository<Subscriber>
  ) {}
  async create(data: Partial<Subscriber>): Promise<Subscriber> {
    const subscriber = this.subscriberRepository.create(data);
    return this.subscriberRepository.save(subscriber);
  }  async findByMobile(mobile: string) {
    const subscriber = await this.subscriberRepository.findOne({ 
      where: { mobile },
      relations: ['user', 'user.transactions']
    });

    console.log('Found subscriber:', subscriber); // Debug log
    return subscriber;
  }  async findOne(id: string | number) {
    return this.subscriberRepository.findOne({
      where: { id: Number(id) },
      relations: ['user', 'user.transactions']
    });
  }
}