import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty } from 'class-validator';

export class VerifyOtpDto {
  @ApiProperty({
    example: 'ac12f33f-8292-4942-9a08-22b0ab08a3c4',
    description: 'Verification ID received when sending OTP'
  })
  @IsString()
  @IsNotEmpty()
  verification_id: string;

  @ApiProperty({
    example: '123456',
    description: 'OTP code to verify'
  })
  @IsString()
  @IsNotEmpty()
  otp: string;
}