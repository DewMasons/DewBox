import { Entity, Column, PrimaryGeneratedColumn, OneToOne, JoinColumn } from 'typeorm';
import { IsDate, IsNotEmpty, IsPhoneNumber, IsString } from 'class-validator';
import { User } from './user.entity';

@Entity('subscribers')
export class Subscriber {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  @IsNotEmpty()
  @IsString()
  firstname: string;

  @Column()
  @IsNotEmpty()
  @IsString()
  surname: string;

  @Column()
  @IsNotEmpty()
  @IsString()
  address1: string;

  @Column()
  @IsNotEmpty()
  @IsString()
  city: string;

  @Column()
  @IsNotEmpty()
  @IsString()
  gender: string;

  @Column()
  @IsNotEmpty()
  @IsString()
  country: string;

  @Column()
  @IsNotEmpty()
  @IsString()
  state: string;

  @Column({ type: 'date' })
  @IsNotEmpty()
  @IsDate()
  dob: Date;

  @Column()
  @IsNotEmpty()
  @IsPhoneNumber()
  mobile: string;

  @Column({ nullable: true })
  @IsPhoneNumber()
  alternatePhone?: string;

  @Column()
  @IsNotEmpty()
  @IsString()
  currency: string;

  @Column({ nullable: true })
  @IsString()
  referral?: string;

  @Column({ nullable: true })
  @IsPhoneNumber()
  referralPhone?: string;

  @Column()
  @IsNotEmpty()
  @IsString()
  nextOfKinName: string;

  @Column()
  @IsNotEmpty()
  @IsPhoneNumber()
  nextOfKinContact: string;

  @Column()
  @IsNotEmpty()
  @IsString()
  password: string;

  @Column({ nullable: true })
  userId: string;

  @OneToOne(() => User, user => user.subscriber, { cascade: true })
  @JoinColumn({ name: 'userId' })
  user: User;
}