import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from '../entities/user.entity';
import { UsersService } from './users.service';
import { UserController } from './user.controller';
import { SubscriberModule } from '../subscriber/subscriber.module';
import { TransactionsModule } from '../transactions/transactions.module';

@Module({
  imports: [TypeOrmModule.forFeature([User]), SubscriberModule, forwardRef(() => TransactionsModule)],
  controllers:[UserController],
  providers: [UsersService],
  exports: [UsersService],
})
export class UsersModule {}