import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty } from 'class-validator';

export class SendOtpDto {
  @ApiProperty({
    example: '+2348012345678',
    description: 'Phone number in international format'
  })
  @IsString()
  @IsNotEmpty()
  recipients: string;
}