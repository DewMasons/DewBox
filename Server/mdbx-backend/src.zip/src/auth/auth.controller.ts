import { Controller, Get, Post, Body, UseGuards, Logger, Request, HttpException, HttpStatus } from '@nestjs/common';
import { AuthService } from './auth.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { JwtAuthGuard } from './jwt-auth.guard';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';

@Controller('auth')
@ApiTags('auth')
export class AuthController {
  private readonly logger = new Logger(AuthController.name);

  constructor(private readonly authService: AuthService) {}

  @Post('register')
  @ApiOperation({ summary: 'Register new user' })
  @ApiResponse({ status: 201, description: 'User successfully registered' })
  async register(@Body() registerDto: RegisterDto) {
    try {
      return await this.authService.register(registerDto);
    } catch (error) {
      this.logger.error(`Registration failed: ${error.message}`);
      throw error;
    }
  }

  @Post('login')
  @ApiOperation({ summary: 'Login user' })
  @ApiResponse({ status: 200, description: 'Login successful' })
  async login(@Body() loginDto: LoginDto) {
    try {
      console.log('Login attempt:', loginDto);
      const result = await this.authService.login(loginDto);
      console.log('Login result:', result);
      return result;
    } catch (error) {
      console.error('Login error details:', error);
      throw error;
    }
  }

@Get('check')
@UseGuards(JwtAuthGuard)
@ApiOperation({ summary: 'Check authentication status' })
@ApiResponse({ status: 200, description: 'Authentication valid' })
async checkAuth(@Request() req) {
  try {
    return {
      isAuthenticated: true,
      user: req.user,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    this.logger.error(`Auth check failed: ${error.message}`);
    throw new HttpException('Failed to check authentication status', HttpStatus.INTERNAL_SERVER_ERROR);
  }
}
}