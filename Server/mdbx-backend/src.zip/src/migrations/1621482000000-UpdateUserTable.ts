import { MigrationInterface, QueryRunner } from "typeorm";

export class UpdateUserTable1621482000000 implements MigrationInterface {
    public async up(queryRunner: QueryRunner): Promise<void> {
        // First create new columns if they don't exist
        await queryRunner.query(`
            ALTER TABLE \`user\` 
            ADD COLUMN IF NOT EXISTS \`name\` varchar(255) NOT NULL,
            ADD COLUMN IF NOT EXISTS \`email\` varchar(255) NOT NULL UNIQUE,
            ADD COLUMN IF NOT EXISTS \`mobile\` varchar(255),
            ADD COLUMN IF NOT EXISTS \`password\` varchar(255) NOT NULL,
            ADD COLUMN IF NOT EXISTS \`balance\` decimal(10,2) NOT NULL DEFAULT 0.00
        `);

        // Then safely drop subscriber_id if it exists
        await queryRunner.query(`
            SET @exist := (
                SELECT COUNT(*)
                FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = 'user'
                AND COLUMN_NAME = 'subscriber_id'
            );
            SET @sqlstmt := IF(
                @exist > 0,
                'ALTER TABLE \`user\` DROP COLUMN \`subscriber_id\`',
                'SELECT "Column subscriber_id does not exist"'
            );
            PREPARE stmt FROM @sqlstmt;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE \`user\`
            ADD COLUMN \`subscriber_id\` varchar(255)
        `);
    }
}