import { Injectable, BadRequestException, UnauthorizedException } from '@nestjs/common';
import * as bcrypt from 'bcryptjs';
import { JwtService } from '@nestjs/jwt';
import { UsersService } from '../users/users.service';
import { SubscriberService } from '../subscriber/subscriber.service';
import { RegisterDto } from './dto/register.dto';
import { User } from '../entities/user.entity';
import { Subscriber } from '../entities/subscriber.entity';

// Helper function to generate a 6-digit random number as a string.
function generateRandomNumber(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

@Injectable()
export class AuthService {
  constructor(
    private readonly usersService: UsersService,
    private readonly subscriberService: SubscriberService,
    private readonly jwtService: JwtService,
  ) {}

  // Update validateUser to use mobile instead of phone
  async validateUser(mobile: string, password: string): Promise<Partial<User> | null> {
    const user = await this.usersService.findByPhone(mobile);
    if (user && (await bcrypt.compare(password, user.password))) {
      const { password, ...result } = user;
      return result;
    }
    return null;
  }  async login(loginDto: any) {
    // First check if the mobile exists in subscribers
    const subscriber = await this.subscriberService.findByMobile(loginDto.mobile);
    let type = 'subscriber';
    let userData: any = null;

    if (subscriber) {
      // Validate subscriber password
      const isPasswordValid = subscriber.password && 
        await bcrypt.compare(loginDto.password, subscriber.password);
      
      if (!isPasswordValid) {
        throw new UnauthorizedException('Invalid credentials');
      }
      
      userData = {
        id: subscriber.id,
        mobile: subscriber.mobile,
        type: 'subscriber',
        firstname: subscriber.firstname,
        surname: subscriber.surname
      };
    } else {
      // If not found in subscribers, try regular users
      const user = await this.usersService.findByPhone(loginDto.mobile);
      if (user) {
        // Validate regular user password
        const isPasswordValid = user.password && await bcrypt.compare(loginDto.password, user.password);
        if (!isPasswordValid) {
          throw new UnauthorizedException('Invalid credentials');
        }
        
        type = 'user';
        userData = {
          id: user.id,
          mobile: user.mobile,
          type: 'user',
          name: user.name,
          email: user.email,
          balance: user.balance
        };
      }
    }

    if (!userData) {
      throw new UnauthorizedException('Invalid credentials');
    }
    const payload = {
      sub: userData.id,
      mobile: userData.mobile,
      type: userData.type
    };

    return {
      access_token: this.jwtService.sign(payload),
      user: userData
    };
  }

  async register(registerDto: RegisterDto) {
    // Validate password
    if (!registerDto.password) {
      throw new BadRequestException('Password is required');
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(registerDto.password, 10);

    // Create user with hashed password
    const user = await this.usersService.create({
      ...registerDto,
      password: hashedPassword,
    });

    // Remove password from response
    const { password, ...result } = user;
    return result;
  }
}