import { MigrationInterface, QueryRunner } from "typeorm";

export class SafeUserUpdate1684654321 implements MigrationInterface {
    public async up(queryRunner: QueryRunner): Promise<void> {
        // First ensure all required columns exist
        await queryRunner.query(`
            ALTER TABLE \`user\`
            ADD COLUMN IF NOT EXISTS \`name\` varchar(255) NOT NULL,
            ADD COLUMN IF NOT EXISTS \`email\` varchar(255) NOT NULL UNIQUE,
            ADD COLUMN IF NOT EXISTS \`mobile\` varchar(255),
            ADD COLUMN IF NOT EXISTS \`password\` varchar(255) NOT NULL,
            ADD COLUMN IF NOT EXISTS \`balance\` decimal(10,2) NOT NULL DEFAULT 0.00,
            MODIFY COLUMN IF EXISTS \`subscriber_id\` varchar(255) NULL
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        // No down migration needed as we're just ensuring columns exist
    }
}