import { Controller, Get, Patch, Body, UseGuards, Request, NotFoundException } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { UsersService } from './users.service';
import { SubscriberService } from '../subscriber/subscriber.service';
import { TransactionsService } from '../transactions/transactions.service';

@Controller('users')
@UseGuards(JwtAuthGuard)
export class UserController {
  constructor(
    private readonly usersService: UsersService,
    private readonly subscriberService: SubscriberService,
    private readonly transactionsService: TransactionsService,
  ) {}  @Get('me')  async getMe(@Request() req) {
    const { mobile, type } = req.user;
    console.log('Request user info:', { mobile, type });

    try {
      // First try to find by mobile in subscribers
      const subscriber = await this.subscriberService.findByMobile(mobile);
      
      if (subscriber) {
        // Get transactions either through the linked user or directly by subscriber ID
        const transactions = subscriber.user ? 
          await this.transactionsService.findAllByUser(subscriber.user.id) :
          await this.transactionsService.findAllBySubscriberId(subscriber.id);

        const balance = transactions
          .filter(t => t.status === 'completed' && t.type === 'contribution')
          .reduce((sum, t) => sum + Number(t.amount), 0);

        return {
          id: subscriber.id,
          name: `${subscriber.firstname} ${subscriber.surname}`,
          mobile: subscriber.mobile,
          balance,
          type: 'subscriber',
          firstname: subscriber.firstname,
          surname: subscriber.surname,
          address1: subscriber.address1,
          city: subscriber.city,
          state: subscriber.state,
          country: subscriber.country,
          userId: subscriber.user?.id // Include linked user ID if exists
        };
      }

      // If not found in subscribers, look for regular user
      const user = await this.usersService.findByMobile(mobile);
      if (!user) {
        throw new NotFoundException('User not found');
      }

      // If user has subscriber_id, get the subscriber details
      if (user.subscriber_id) {
        const linkedSubscriber = await this.subscriberService.findOne(user.subscriber_id);
        if (linkedSubscriber) {
          return this.getMe({ user: { mobile: linkedSubscriber.mobile, type: 'subscriber' }});
        }
      }

      const { password, ...userWithoutPassword } = user;
      return {
        ...userWithoutPassword,
        type: 'user'
      };
    } catch (error) {
      console.error('Error in getMe:', error);
      throw error;
    }
  }

  @Patch('profile')
  async updateProfile(@Request() req, @Body() data: any) {
    const userId = req.user.userId || req.user.id;
    const user = await this.usersService.update(userId, data);
    if (user && user.password !== undefined) {
      const { password, ...rest } = user;
      return rest;
    }
    return user;
  }
}
