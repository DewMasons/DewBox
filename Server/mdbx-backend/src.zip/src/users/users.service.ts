import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from '../entities/user.entity';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private usersRepository: Repository<User>,
  ) {}

  async create(userData: Partial<User>): Promise<User> {
    const user = this.usersRepository.create(userData);
    return this.usersRepository.save(user);
  }

  async findOne(id: string): Promise<User> {
    const user = await this.usersRepository.findOne({
      where: { id },
      relations: ['transactions']
    });

    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }

    return user;
  }

  async update(id: string, data: Partial<User>): Promise<User> {
    // Only allow updating certain fields for security
    const allowedFields = ['name', 'email', 'mobile', 'subscriber_id']; // removed 'balance'
    const updateData: Partial<User> = {};
    for (const key of allowedFields) {
      if (data[key] !== undefined) {
        updateData[key] = data[key];
      }
    }
    await this.usersRepository.update(id, updateData);
    return this.findOne(id);
  }
  async findByMobile(mobile: string) {
    const user = await this.usersRepository.findOne({ 
      where: { mobile },
      relations: ['transactions'] 
    });
    return user;
  }

  // For backward compatibility with code using findByPhone
  async findByPhone(mobile: string) {
    return this.findByMobile(mobile);
  }
}