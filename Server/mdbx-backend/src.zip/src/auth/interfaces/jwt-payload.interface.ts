// filepath: c:\Users\user\Desktop\MDBX Fullstack\Server\mdbx-backend\src\auth\interfaces\jwt-payload.interface.ts
export interface JwtPayload {
  sub: number;
  mobile: string;
  type?: string;
  iat?: number;
  exp?: number;
}