
import { Strategy } from 'passport-local';
import { PassportStrategy } from '@nestjs/passport';
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { AuthService } from './auth.service';

@Injectable()
export class LocalStrategy extends PassportStrategy(Strategy) {
  constructor(private authService: AuthService) {
    super({
      usernameField: 'mobile',
      passwordField: 'password',
      passReqToCallback: false
    });
  }

  async validate(mobile: string, password: string): Promise<any> {
    try {
      console.log('Validating user:', { mobile }); // Debug log
      
      const user = await this.authService.validateUser(mobile, password);
      
      if (!user) {
        console.log('User validation failed'); // Debug log
        throw new UnauthorizedException('Invalid mobile number or password');
      }
      
      console.log('User validated successfully:', user.id); // Debug log
      return user;
      
    } catch (error) {
      console.error('Validation error:', error); // Debug log
      throw new UnauthorizedException(error.message || 'Authentication failed');
    }
  }
}