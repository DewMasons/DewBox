import { Controller, Post, Body, UseGuards, Request, Get } from '@nestjs/common';
import { TransactionsService } from './transactions.service';
import { CreateTransactionDto } from './dto/create-transaction.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@Controller('users/transactions')
@UseGuards(JwtAuthGuard)
export class TransactionsController {
  constructor(private readonly transactionsService: TransactionsService) {}

  @Post('contribute')
  async contribute(@Request() req, @Body() createTransactionDto: CreateTransactionDto) {
    return this.transactionsService.createContribution(req.user.userId, createTransactionDto);
  }

  @Get()
  async findAll(@Request() req) {
    return this.transactionsService.findAllByUser(req.user.userId);
  }
}