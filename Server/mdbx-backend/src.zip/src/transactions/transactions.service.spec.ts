import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { TransactionsService } from './transactions.service';
import { Transaction, TransactionType, TransactionStatus } from '../entities/transaction.entity';
import { UsersService } from '../users/users.service';
import { User } from '../entities/user.entity';
import { NotFoundException } from '@nestjs/common';

describe('TransactionsService', () => {
  let service: TransactionsService;
  let transactionRepository: Repository<Transaction>;
  let usersService: UsersService;

  const mockTransactionRepository = {
    create: jest.fn(),
    save: jest.fn(),
  };

  const mockUsersService = {
    findOne: jest.fn(),
    update: jest.fn(),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        TransactionsService,
        {
          provide: getRepositoryToken(Transaction),
          useValue: mockTransactionRepository,
        },
        {
          provide: UsersService,
          useValue: mockUsersService,
        },
      ],
    }).compile();

    service = module.get<TransactionsService>(TransactionsService);
    transactionRepository = module.get<Repository<Transaction>>(getRepositoryToken(Transaction));
    usersService = module.get<UsersService>(UsersService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('createContribution', () => {
    it('should create a contribution transaction and update user balance', async () => {
      const userId = '123';
      const createTransactionDto = {
        type: TransactionType.CONTRIBUTION,
        amount: 100,
        currency: 'NGN',
      };

      const mockUser = {
        id: userId,
        balance: 500,
      } as User;

      const mockTransaction = {
        id: '456',
        type: TransactionType.CONTRIBUTION,
        amount: 100,
        currency: 'NGN',
        status: TransactionStatus.PENDING,
        user: mockUser,
      } as Transaction;

      mockUsersService.findOne.mockResolvedValue(mockUser);
      mockTransactionRepository.create.mockReturnValue(mockTransaction);
      mockTransactionRepository.save.mockResolvedValue(mockTransaction);

      const result = await service.createContribution(userId, createTransactionDto);

      expect(result).toEqual(mockTransaction);
      expect(mockUsersService.update).toHaveBeenCalledWith(userId, {
        balance: 600, // Initial balance + contribution amount
      });
    });

    it('should throw NotFoundException if user not found', async () => {
      mockUsersService.findOne.mockResolvedValue(null);

      await expect(
        service.createContribution('123', {
          type: TransactionType.CONTRIBUTION,
          amount: 100,
          currency: 'NGN',
        })
      ).rejects.toThrow(NotFoundException);
    });
  });
});