# Code Citations

## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port:
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port:
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
        database: config
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
        database: config
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
        database: configService.get('
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
        database: configService.get('
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
        database: configService.get('DB_NAME'),
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
        database: configService.get('DB_NAME'),
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
        database: configService.get('DB_NAME'),
        entities:
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
        database: configService.get('DB_NAME'),
        entities:
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
        database: configService.get('DB_NAME'),
        entities: [__dirname +
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
        database: configService.get('DB_NAME'),
        entities: [__dirname +
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
        database: configService.get('DB_NAME'),
        entities: [__dirname + '/entities
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
        database: configService.get('DB_NAME'),
        entities: [__dirname + '/entities
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
        database: configService.get('DB_NAME'),
        entities: [__dirname + '/entities/*.entity{.
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
        database: configService.get('DB_NAME'),
        entities: [__dirname + '/entities/*.entity{.
```


## License: unknown
https://github.com/corbig/nest-notes-api-example/blob/df7ba585bc5dd22b43bf67f3ad22dcd54ee8be89/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
        database: configService.get('DB_NAME'),
        entities: [__dirname + '/entities/*.entity{.ts,.
```


## License: unknown
https://github.com/alejandrocabriales/monorepo-ecommerce/blob/80bc1c8872a05b9d2bb1c947201ee3c8fe3c4cd7/packages/ecommerce-backend/src/app.module.ts

```
.get('DB_HOST'),
        port: configService.get('DB_PORT'),
        username: configService.get('DB_USERNAME'),
        password: configService.get('DB_PASSWORD'),
        database: configService.get('DB_NAME'),
        entities: [__dirname + '/entities/*.entity{.ts,.
```

