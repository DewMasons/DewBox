import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Transaction, TransactionType } from '../entities/transaction.entity';
import { UsersService } from '../users/users.service';
import { CreateTransactionDto } from './dto/create-transaction.dto';

@Injectable()
export class TransactionsService {
  constructor(
    @InjectRepository(Transaction)
    private transactionsRepository: Repository<Transaction>,
    private usersService: UsersService,
  ) {}

  async createContribution(userId: string, createTransactionDto: CreateTransactionDto): Promise<Transaction> {
    const user = await this.usersService.findOne(userId);
    
    if (!user) {
      throw new NotFoundException('User not found');
    }

    const transaction = this.transactionsRepository.create({
      ...createTransactionDto,
      type: TransactionType.CONTRIBUTION,
      user,
    });

    await this.transactionsRepository.save(transaction);

    // Update user balance for contribution
    const newBalance = user.balance + transaction.amount;
    await this.usersService.update(userId, { balance: newBalance });

    return transaction;
  }

  // Add method to get all transactions for a user
  async findAllByUser(userId: string): Promise<Transaction[]> {
    return this.transactionsRepository.find({
      where: { user: { id: userId } },
      relations: ['user'],
      order: { createdAt: 'DESC' },
    });
  }

  // Get all transactions for a subscriber by subscriber id (userId in transactions table)
  async findAllBySubscriberId(subscriberId: string | number): Promise<Transaction[]> {
    // Always convert to string for the query, as user.id is varchar(36)
    return this.transactionsRepository.find({
      where: { user: { id: String(subscriberId) } as any },
      order: { createdAt: 'DESC' },
    });
  }
}