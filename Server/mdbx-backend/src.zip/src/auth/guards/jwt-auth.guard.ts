import { Injectable, UnauthorizedException, Logger } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  private readonly logger = new Logger(JwtAuthGuard.name);

  handleRequest(err: any, user: any, info: any) {
    this.logger.debug(`JWT validation attempt: ${JSON.stringify({ user, info })}`);
    
    if (info instanceof Error) {
      this.logger.error(`JWT Error: ${info.message}`);
      throw new UnauthorizedException(info.message);
    }
    
    if (err || !user) {
      this.logger.error(`Authentication failed: ${err?.message || 'No user found'}`);
      throw err || new UnauthorizedException();
    }
    
    return user;
  }
}