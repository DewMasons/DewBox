import { Controller, Post, Body, HttpException, HttpStatus } from '@nestjs/common';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { SmsService } from './sms.service';
import { SendOtpDto } from './dto/send-otp.dto';
import { VerifyOtpDto } from './dto/verify-otp.dto';

@ApiTags('SMS')
@Controller('api/sms')
export class SmsController {
  constructor(private readonly smsService: SmsService) {}

  @Post('sendotp')
  @ApiOperation({ summary: 'Send OTP via SMS' })
  @ApiResponse({ status: 200, description: 'OTP sent successfully' })
  async sendOtp(@Body() sendOtpDto: SendOtpDto) {
    try {
      const result = await this.smsService.sendOtp(sendOtpDto);
      return result;
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to send OTP',
        HttpStatus.BAD_REQUEST
      );
    }
  }

  @Post('verifyotp')
  @ApiOperation({ summary: 'Verify OTP code' })
  @ApiResponse({ status: 200, description: 'OTP verified successfully' })
  @ApiResponse({ status: 400, description: 'Invalid OTP or verification failed' })
  async verifyOtp(@Body() verifyOtpDto: VerifyOtpDto) {
    try {
      const result = await this.smsService.verifyOtp(verifyOtpDto);
      return result;
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to verify OTP',
        HttpStatus.BAD_REQUEST
      );
    }
  }
}