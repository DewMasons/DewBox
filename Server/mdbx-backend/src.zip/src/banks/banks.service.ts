import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import axios from 'axios';

@Injectable()
export class BanksService {
  constructor(private configService: ConfigService) {}

  async getNigerianBanks() {
    try {
      const response = await axios.get('https://api.paystack.co/bank', {
        headers: {
          Authorization: `Bearer ${this.configService.get<string>('PAYSTACK_SECRET_KEY')}`,
        },
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  }
}
