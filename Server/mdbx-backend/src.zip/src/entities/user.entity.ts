import { Entity, Column, PrimaryGeneratedColumn, OneToMany, OneToOne } from 'typeorm';
import { Transaction } from './transaction.entity';
import { Subscriber } from './subscriber.entity';

@Entity()
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  name: string;

  @Column({ unique: true })
  email: string;

  @Column({ nullable: true })
  mobile: string;

  @Column()
  password: string;

  @Column('decimal', { precision: 10, scale: 2, default: 0 })
  balance: number;

  @Column({ nullable: true })
  subscriber_id: string;

  @OneToMany(() => Transaction, transaction => transaction.user)
  transactions: Transaction[];

  @OneToOne(() => Subscriber, subscriber => subscriber.user)
  subscriber: Subscriber;

  @OneToOne(() => User, user => user.subscriber)
  user: User;
}