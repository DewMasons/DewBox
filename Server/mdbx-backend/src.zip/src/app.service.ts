import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class AppService {
  constructor(private configService: ConfigService) {}

  getHello(): string {
    return 'MyDewbox API';
  }

  checkHealth() {
    return {
      status: 'ok',
      timestamp: new Date(),
      environment: this.configService.get('NODE_ENV')
    };
  }

  getVersion() {
    return {
      version: '1.0.0',
      apiEndpoints: {
        auth: {
          register: '/api/auth/register',
          login: '/api/auth/login',
          verify: '/api/auth/verify'
        },
        user: {
          profile: '/api/user/profile',
          transactions: '/api/user/transactions'
        },
        wallet: {
          balance: '/api/wallet/balance',
          contribute: '/api/wallet/contribute',
          withdraw: '/api/wallet/withdraw'
        }
      }
    };
  }
}
