import { Injectable, Logger } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';
import { lastValueFrom } from 'rxjs';
import { SendOtpDto } from './dto/send-otp.dto';
import { VerifyOtpDto } from './dto/verify-otp.dto';

@Injectable()
export class SmsService {
  private readonly logger = new Logger(SmsService.name);
  private readonly kudiSmsUrl = 'https://my.kudisms.net/api';
  private readonly apiKey: string;
  private readonly sender: string;
  private readonly appNameCode: string;
  private readonly templateCode: string;

  constructor(
    private readonly httpService: HttpService,
    private readonly configService: ConfigService,
  ) {
    this.apiKey = "F73abjfTPs2XHWqeAGMDUYrOZ0E89Blcpo4nIvzRuJtkSx1CLiQyVNdKwh5gm6";
    this.sender = this.configService.get<string>('KUDISMS_SENDER') || 'MyDewbox';
    this.appNameCode = '6264483761';
    this.templateCode = '4674358581';
  }

  async sendOtp(sendOtpDto: SendOtpDto) {
    try {
      const params = {
        token: this.apiKey,
        senderID: this.sender,
        recipients: sendOtpDto.recipients,
        otp: Math.floor(100000 + Math.random() * 900000).toString(), // Generate 6-digit OTP
        appnamecode: this.appNameCode,
        templatecode: this.templateCode
      };

      const response = await lastValueFrom(
        this.httpService.get(`${this.kudiSmsUrl}/otp`, { params })
      );

      if (response.data?.error_code === '000') {
        this.logger.log(`OTP sent successfully to ${sendOtpDto.recipients}`);
        return {
          success: true,
          verification_id: response.data.verification_id,
          message: 'OTP sent successfully'
        };
      } else {
        throw new Error(response.data?.msg || 'Failed to send OTP');
      }
    } catch (error) {
      this.logger.error('OTP sending failed:', error.response?.data || error.message);
      throw new Error(error.response?.data?.msg || error.message);
    }
  }

  async verifyOtp(verifyOtpDto: VerifyOtpDto) {
    try {
      const payload = {
        token: this.apiKey,
        ...verifyOtpDto
      };

      const response = await lastValueFrom(
        this.httpService.post(`${this.kudiSmsUrl}/verifyotp`, payload)
      );

      if (response.data?.error_code === '000') {
        this.logger.log('OTP verified successfully');
        return response.data;
      } else {
        throw new Error(response.data?.msg || 'Invalid OTP');
      }
    } catch (error) {
      this.logger.error('OTP verification failed:', error.response?.data || error.message);
      throw new Error(error.response?.data?.msg || 'OTP verification failed');
    }
  }
}